#include "HC_SR04.h"

uint16_t Time;//Echo高电平时间
float Distance;//转换之后的距离

void TIM2_Count_Init(void)//定时器2初始化
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

    /* TIM2 clock enable */
    /* TIM2 时钟使能 */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    /* Time base configuration */
    /* TIM2 配置 定时1s */
    TIM_TimeBaseStructure.TIM_Period = 0xFFFF;//设置计数值
    TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1;//设置分频值(0-0xFFFF 0-65535) 72MHz/72 = 1MHz 1s计数1000000
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//向上计数
    
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    
    /* TIM2 enable counter */
    /* TIM2使能计数 */
    TIM_Cmd(TIM2, ENABLE);
}

/* TRIG：PA1 输出  ECHO：PA2 输入 */
void Trig_Echo_Init(void)//HC_SR04 TRIG ECHO引脚初始化 PA1 PA2
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    /* Enable GPIOA clock */
    /* 使能GPIOA时钟 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 
    
    /* Configure PA1 in output pushpull mode */
    /* 配置PA1 推挽输出模式 */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Configure PA2 in input floating mode */
    /* 配置PA2 浮空输入模式 */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void HC_SR04_Data(void)//Trig发送高电平触发测距 获取Echo高电平时间并转换成距离
{
    TIM_Cmd(TIM2, ENABLE);//开启定时器
    
    /* 触发Trig测距，给至少 10us 的高电平信号 */
    Trig_H;
    Delay_us(20);
    Trig_L;
    
    /* 获得Echo信号高电平持续的时间 */
    while(Echo == 0);
    TIM_SetCounter(TIM2, 0);//开启计数
    while(Echo == 1);

    TIM_Cmd(TIM2, DISABLE);//关闭定时器
    Time = TIM_GetCounter(TIM2);//获取计数值 对应时间单位μs
    
    /* 将Echo信号高电平时间装换成距离 */
    Distance = Time*0.034/2;//340m/s 转换成 0.034cm/μs
    printf("Distance = %.2f cm\n",Distance);
            
    Delay_us(100000);//打印时间间隔 0.1s
}
