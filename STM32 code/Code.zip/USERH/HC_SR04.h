#ifndef __HC_SR04_H__
#define __HC_SR04_H__

#include "stm32f10x.h"
#include "SysTick.h"
#include "UART.h"

extern uint16_t Time;//Echo高电平时间
extern float Distance;//转换之后的距离

#define Trig_H GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_SET)
#define Trig_L GPIO_WriteBit(GPIOA, GPIO_Pin_1, Bit_RESET)

#define Echo GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2)

void TIM2_Count_Init(void);//定时器2初始化
void Trig_Echo_Init(void);//HC_SR04 TRIG ECHO引脚初始化 PA1 PA2
void HC_SR04_Data(void);//Trig发送高电平触发测距 获取Echo高电平时间并转换成距离

#endif
